import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";


import Navbar from "../../components/common/Navbar";

import HeroIllustration from "../../components/common/HeroIllustration";

import FeatureSection from "../../components/common/FeatureSection";

import MarzanoPreview from "../../components/common/MarzanoPreview";

import CTASection from "../../components/common/CTASection";



export default function Landing(){


return (


<div id="home" className="
min-h-screen
bg-[#FBFCF8]
overflow-hidden
">


{/* ================= NAVBAR ================= */}

<Navbar />



{/* ================= HERO SECTION ================= */}


<section className="
relative
grid
md:grid-cols-2
items-center
gap-10
px-12
pt-16
pb-24
">


{/* Background Gradient Decoration */}


<div className="
absolute
top-20
right-10
w-[420px]
h-[420px]
bg-[#CFE8DD]
rounded-full
blur-3xl
opacity-40
">
</div>



<div className="
relative
z-10
">


<motion.h1

initial={{

opacity:0,

x:-40

}}

animate={{

opacity:1,

x:0

}}

transition={{

duration:0.8

}}

className="
text-5xl
md:text-6xl
font-extrabold
leading-tight
text-[#24332D]
"

>


Learn English


<br/>


Through Stories,


<br/>


Creativity,


<br/>


and Games



</motion.h1>




<motion.p

initial={{

opacity:0,

y:20

}}

animate={{

opacity:1,

y:0

}}

transition={{

delay:0.3,

duration:0.8

}}

className="
mt-8
text-lg
md:text-xl
text-[#6C7973]
max-w-xl
leading-relaxed
"

>


Interactive English learning platform
designed with Marzano Learning Journey,
creative projects, and interactive games.


</motion.p>




<motion.div

initial={{

opacity:0

}}

animate={{

opacity:1

}}

transition={{

delay:0.5

}}

className="
mt-10
flex
gap-5
items-center
"

>


<Link

to="/login"

className="
flex
items-center
gap-3
bg-[#25324A]
text-white
px-8
py-4
rounded-2xl
shadow-xl
hover:-translate-y-1
hover:shadow-2xl
transition-all
duration-300
"

>


Start Learning


<ArrowRight size={20}/>


</Link>



<button

className="
px-8
py-4
rounded-2xl
border-2
border-[#25324A]
text-[#24332D]
hover:bg-[#25324A]
hover:text-white
transition-all
duration-300
"


>


Explore Journey


</button>



</motion.div>


</div>





{/* Hero Illustration */}


<motion.div

initial={{

opacity:0,

scale:0.8

}}

animate={{

opacity:1,

scale:1

}}

transition={{

duration:0.8

}}

className="
relative
z-10
"

>


<HeroIllustration />


</motion.div>



</section>





{/* ================= FEATURE SECTION ================= */}



<FeatureSection />






{/* ================= MARZANO JOURNEY ================= */}



<MarzanoPreview />






{/* ================= CTA SECTION ================= */}



<CTASection />





{/* ================= FOOTER ================= */}



<footer className="
py-10
text-center
text-[#6C7973]
text-sm
">


© 2026 MarzaLearn.
Learn. Create. Grow.


</footer>



</div>


)


}