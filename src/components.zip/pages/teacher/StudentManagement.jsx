import { useEffect, useState } from "react";
import { getStudentsByClass } from "../../services/teacher";

export default function StudentManagement() {
  const [cls, setCls] = useState("XC");
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadStudents() {
      setLoading(true);
      setError("");

      try {
        const result = await getStudentsByClass(cls);

        console.log("Students from Supabase:", result);

        setStudents(Array.isArray(result) ? result : []);
      } catch (err) {
        console.error("Student RPC Error:", err);
        setError("Data siswa tidak dapat dimuat.");
        setStudents([]);
      } finally {
        setLoading(false);
      }
    }

    loadStudents();
  }, [cls]);

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-5 text-[#24344d]">
        Student Management
      </h1>

      <div className="flex gap-3 mb-5">
        {["XC", "XD"].map((c) => (
          <button
            key={c}
            onClick={() => setCls(c)}
            className={`px-5 py-2 rounded-xl shadow font-semibold ${
              cls === c
                ? "bg-[#24344d] text-white"
                : "bg-white text-[#24344d]"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      <p className="mb-3 text-[#24344d]">
        Kelas {cls}: {students.length} siswa
      </p>

      {loading && <p>Memuat data siswa...</p>}

      {error && (
        <p className="text-red-600">
          {error}
        </p>
      )}

      {!loading && !error && students.length === 0 && (
        <p>
          Belum ada siswa terdaftar pada kelas {cls}.
        </p>
      )}

      <div className="grid gap-3">
        {students.map((student) => (
          <div
            key={student.id}
            className="bg-white rounded-xl p-4 shadow"
          >
            <p className="font-semibold text-[#24344d]">
              {student.full_name}
            </p>
            <p>
              {student.student_id}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
