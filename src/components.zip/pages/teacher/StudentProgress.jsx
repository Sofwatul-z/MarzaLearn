import {useEffect,useState} from 'react';
import {getStudentProgress} from '../../services/teacher';
export default function StudentProgress({student}){
 const [data,setData]=useState([]);
 useEffect(()=>{if(student)getStudentProgress(student.id).then(setData)},[student]);
 return <div>{data.map(p=><div key={p.id}>Chapter {p.chapter_id}: {p.percentage || 0}%</div>)}</div>
}
