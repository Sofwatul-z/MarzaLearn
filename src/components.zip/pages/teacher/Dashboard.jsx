import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import {
Users,
ClipboardCheck,
BarChart3,
Bell,
FileText
} from "lucide-react";

import { useAuth } from "../../hooks/useAuth";


export default function TeacherDashboard(){

const { profile, signOut } = useAuth();
const navigate = useNavigate();

async function handleLogout(){
  await signOut();
  navigate("/login", { replace: true });
}

const teacherName =
profile?.full_name || "Teacher MarzaLearn";


const stats=[
{
title:"Students",
value:"1",
desc:"Active learners",
icon:<Users/>
},
{
title:"Pending Review",
value:"0",
desc:"Need feedback",
icon:<ClipboardCheck/>
},
{
title:"Average Score",
value:"-",
desc:"Class performance",
icon:<BarChart3/>
},
{
title:"Notifications",
value:"0",
desc:"New activities",
icon:<Bell/>
}
];


return(

<div className="
min-h-screen
bg-gradient-to-br
from-[#fff9f1]
via-[#f2faff]
to-[#dff3ff]
px-8
lg:px-16
py-10
overflow-hidden
">


{/* NAVBAR */}

<div className="
flex
justify-between
items-center
mb-14
">

<div>

<h1 className="
text-3xl
font-black
text-[#24344d]
">
MarzaLearn
</h1>

<p className="
text-slate-500
mt-1
">
Teacher Area · {teacherName}
</p>

</div>


<div className="
flex
gap-4
">

<button
className="
bg-white
px-6
py-3
rounded-2xl
shadow-md
"
>
👩‍🏫 Teacher Panel
</button>


<button
onClick={handleLogout}
className="
bg-[#24344d]
text-white
px-6
py-3
rounded-2xl
shadow-lg
"
>
Logout
</button>

</div>


</div>





{/* HERO */}

<section
className="
grid
lg:grid-cols-2
gap-10
items-center
mb-16
">


<div>


<motion.h2

initial={{
opacity:0,
x:-30
}}

animate={{
opacity:1,
x:0
}}

className="
text-5xl
lg:text-6xl
font-black
leading-tight
text-[#24344d]
"
>

Welcome,
<br/>

{teacherName}

<span>
👋
</span>

</motion.h2>


<p
className="
mt-6
text-lg
text-slate-600
max-w-xl
"
>

Monitor student progress,
review submissions,
and guide your MarzaLearn classroom
journey.

</p>



<div className="
flex
gap-4
mt-8
">

<Link
 to="/teacher/students"
 className="
bg-[#24344d]
!text-white
px-8
py-4
rounded-2xl
shadow-xl
hover:-translate-y-1
transition
font-semibold
"
>
Student Management
</Link>


<button
className="
border
border-[#24344d]
px-8
py-4
rounded-2xl
bg-white/50
"
>
View Analytics
</button>


</div>


</div>





{/* CHARACTER AREA */}


<div
className="
relative
h-[380px]
flex
justify-center
items-center
"
>


<motion.div

animate={{
y:[0,-20,0]
}}

transition={{
duration:4,
repeat:Infinity
}}

className="
text-[170px]
"
>

👩‍🏫

</motion.div>



<motion.div

animate={{
rotate:[0,10,0]
}}

transition={{
duration:3,
repeat:Infinity
}}

className="
absolute
top-10
right-20
bg-white
p-5
rounded-3xl
shadow-xl
text-4xl
"
>

📋

</motion.div>



<motion.div

animate={{
y:[0,15,0]
}}

transition={{
duration:3,
repeat:Infinity
}}

className="
absolute
bottom-20
left-20
bg-[#c8f4df]
p-5
rounded-3xl
shadow-xl
text-4xl
"
>

✅

</motion.div>


</div>


</section>





{/* STATISTIC */}

<section
className="
grid
md:grid-cols-2
xl:grid-cols-4
gap-6
mb-14
">


{
stats.map((item,index)=>(


<motion.div

key={index}

whileHover={{
y:-10
}}

className="
bg-white/70
backdrop-blur-xl
rounded-[32px]
p-7
shadow-xl
border
border-white
"

>


<div
className="
w-14
h-14
rounded-2xl
bg-[#dff2ff]
flex
items-center
justify-center
text-[#24344d]
mb-5
"
>

{item.icon}

</div>


<h3
className="
font-bold
text-lg
"
>
{item.title}
</h3>


<h2
className="
text-4xl
font-black
mt-3
"
>
{item.value}
</h2>


<p
className="
text-slate-500
mt-2
"
>
{item.desc}
</p>


</motion.div>


))
}


</section>





{/* OVERVIEW */}


<section
className="
bg-white/70
backdrop-blur-xl
rounded-[40px]
p-10
shadow-xl
"
>


<div
className="
flex
items-center
gap-4
"
>

<FileText/>

<h2
className="
text-3xl
font-black
"
>
Teaching Overview
</h2>

</div>



<p
className="
mt-5
text-slate-600
max-w-3xl
"
>
Manage chapters, review student activities,
and monitor learning progress from one
teacher workspace.
</p>


<div
className="
grid
md:grid-cols-3
gap-6
mt-8
"
>


<div className="
rounded-3xl
bg-[#dff3ff]
p-6
font-bold
">
📚 Chapter Management
</div>


<div className="
rounded-3xl
bg-[#ddfbe9]
p-6
font-bold
">
✏️ Student Review
</div>


<div className="
rounded-3xl
bg-[#fff0c7]
p-6
font-bold
">
📊 Class Analytics
</div>


</div>


</section>



</div>

)

}